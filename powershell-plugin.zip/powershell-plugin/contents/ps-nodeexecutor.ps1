#!/usr/bin/powershell
$PlainPassword = $ENV:RD_CONFIG_PASS

$SecurePassword = ConvertTo-SecureString $PlainPassword -AsPlainText -Force

$Credentials = New-Object System.Management.Automation.PSCredential -ArgumentList $ENV:RD_CONFIG_USER, $SecurePassword

if ($ENV:RD_EXEC_COMMAND -like "chmod +x*") {
    write-output "skip chmod"
}
elseif ( $ENV:RD_EXEC_COMMAND -like "rm -f*") {
    write-output "remove file"
    $path = $ENV:RD_EXEC_COMMAND -replace "rm -f "
    write-output $path
    $path = "$path"
    remove-item $path
}
elseif ($ENV:RD_EXEC_COMMAND -like "/tmp/*") {
    $path = "$ENV:RD_EXEC_COMMAND"
    if ($ENV:RD_NODE_DESCRIPTION -like "Rundeck server node") {
        #we are running on local node
        Write-Output "running on local node"
        & $path
    }
    else {
        Write-Output "from executor sending $ENV:RD_EXEC_COMMAND as $ENV:RD_CONFIG_USER"
        Invoke-Command -ComputerName $ENV:RD_NODE_NAME -Credential $Credentials -Filepath $path -Authentication $ENV:RD_CONFIG_AUTHTYPE
    }
}
else {
    $scriptblock = [Scriptblock]::Create($ENV:RD_EXEC_COMMAND)
    if ($ENV:RD_NODE_DESCRIPTION -like "Rundeck server node") {
        Write-Output "running on local node"
        & $scriptblock
    }
    else {
        Write-Output "sending $ENV:RD_EXEC_COMMAND to $ENV:RD_NODE_NAME as $ENV:RD_CONFIG_USER"
        Invoke-Command -ComputerName $ENV:RD_NODE_NAME -Credential $Credentials -Command $scriptblock -Authentication $ENV:RD_CONFIG_AUTHTYPE
    }
}
