#!/usr/bin/powershell
Param(
    $Filepath,
    $Destpath
)
$Destpath = "$Destpath.ps1"
copy-item $Filepath $Destpath
$Destpath